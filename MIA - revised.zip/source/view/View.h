#ifndef View_H
#define View_H

#include <iostream>

class View {
	public :
		//hanya berisi Ctor dan Dtor karena hanya berisi layout
		View();
		~View();
		void ShowBentuk(int a);
		char GetBentuk(int a);
		
	private :

};



#endif //PETAK_H
