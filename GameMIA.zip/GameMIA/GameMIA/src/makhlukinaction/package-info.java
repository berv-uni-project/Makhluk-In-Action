/** makhlukinaction is group of mvc game of makhluk. */
package makhlukinaction;