/** makhluk is group of makhluk and child of makhluk. */
package makhluk;