/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author JJ
 */

public final class MakhlukPlayer extends Makhluk {

    private static int xPlayer;
    private static int yPlayer;
    private static final int DEFAULT_POWER_LEVEL = 61;
    private static final int EVOLVE_REQ = 10;
    private int evolution;

    /**.
     * @param a
     * @param b
     * private constructor of MakhlukPlayer, setting all value
     */
    private MakhlukPlayer(int a, int b) {
        powerlevel = DEFAULT_POWER_LEVEL;
        type = 0;
        x = xPlayer = a;
        y = xPlayer = b;
        evolution = 0;
    }
    
    
    /**.
     * Creating player
     */
    public static final void spawnPlayer() {
        MakhlukPlayer player = new MakhlukPlayer(0, 0);
    }

    @Override
    public void move() {
        x = xPlayer;
        y = yPlayer;
    }
    
    /**.
     * @param direction 
     * function to move player with key press from keyboard
     */
    public void move(int direction) {
        switch (direction) {
            case 1 :
                xPlayer += 1;
                break;
            case 2 :
                yPlayer += 1;
                break;
            case 3 :
                xPlayer -= 1;
                break;
            case 4 :
                yPlayer -= 1;
                break;
            default :
        }
    }

    public static final void playerUp() {
        xPlayer++;
    }
    public static final void playerDown() {
        xPlayer--;
    }
    public static final void playerRight() {
        yPlayer++;
    }
    public static final void playerLeft() {
        yPlayer--;
    }

    /**.
     * procedure to notify that player has eaten something.
     * powerlevel will be increased by 1 every Makhluk Player eat
     * also trigger for evolving
     */
    public void playerEat() {
        powerlevel = powerlevel + 1;
        int powernow = powerlevel - DEFAULT_POWER_LEVEL - (evolution * 10);
        if (powernow > EVOLVE_REQ) {
            evolution++;
        }
    }

}
