/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package makhlukinaction;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import makhluk.Makhluk;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Bervianto Leo P
 */
public class BoardTest {
    
    public BoardTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of drawGameOver method, of class Board.
     */
    @Test
    public void testDrawGameOver() {
        System.out.println("drawGameOver");
    }

    /**
     * Test of drawWin method, of class Board.
     */
    @Test
    public void testDrawWin() {
        System.out.println("drawWin");
    }

    /**
     * Test of drawborder method, of class Board.
     */
    @Test
    public void testDrawborder() {
        System.out.println("drawborder");
    }

    /**
     * Test of paintComponent method, of class Board.
     */
    @Test
    public void testPaintComponent() {
        System.out.println("paintComponent");
    }

    /**
     * Test of actionPerformed method, of class Board.
     */
    @Test
    public void testActionPerformed() {
        System.out.println("actionPerformed");
    }

    /**
     * Test of atas method, of class Board.
     */
    @Test
    public void testAtas() {
        System.out.println("atas");
    }

    /**
     * Test of bawah method, of class Board.
     */
    @Test
    public void testBawah() {
        System.out.println("bawah");
    }

    /**
     * Test of kiri method, of class Board.
     */
    @Test
    public void testKiri() {
        System.out.println("kiri");
    }

    /**
     * Test of kanan method, of class Board.
     */
    @Test
    public void testKanan() {
        System.out.println("kanan");
    }

    /**
     * Test of keyPressed method, of class Board.
     */
    @Test
    public void testKeyPressed() {
        System.out.println("keyPressed");

    }

    /**
     * Test of keyTyped method, of class Board.
     */
    @Test
    public void testKeyTyped() {
        System.out.println("keyTyped");
    }

    /**
     * Test of keyReleased method, of class Board.
     */
    @Test
    public void testKeyReleased() {
        System.out.println("keyReleased");
    }
    
}
