/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package makhlukinaction;

import java.util.ArrayList;
import makhluk.Makhluk;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Bervianto Leo P
 */
public class ControlCommandTest {
    
    public ControlCommandTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Commander method, of class ControlCommand.
     */
    @Test
    public void testCommander() {
        System.out.println("Commander");
    }

    /**
     * Test of run method, of class ControlCommand.
     */
    @Test
    public void testRun() {
        System.out.println("run");
    }

    /**
     * Test of getArrayList method, of class ControlCommand.
     */
    @Test
    public void testGetArrayList() {
        System.out.println("getArrayList");
    }

    /**
     * Test of getBoard method, of class ControlCommand.
     */
    @Test
    public void testGetBoard() {
        System.out.println("getBoard");
    }

    /**
     * Test of checkCollision method, of class ControlCommand.
     */
    @Test
    public void testCheckCollision() {
        System.out.println("checkCollision");
    }

    /**
     * Test of checkPlayer method, of class ControlCommand.
     */
    @Test
    public void testCheckPlayer() {
        System.out.println("checkPlayer");
    }

    /**
     * Test of checkWin method, of class ControlCommand.
     */
    @Test
    public void testCheckWin() {
        System.out.println("checkWin");
    }
    
}
