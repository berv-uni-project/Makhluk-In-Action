#ifndef PETAK_H
#define PETAK_H
/* Definisi Kelas Petak */

#include "ListMakhluk.h"
#include <iostream>
#include <cstdlib>
#include <time.h>

//#define WIDTH 20
//#define HIGH 20

//#define ListOfMakhluk int

class Petak {
	public :
		Petak();
		Petak(int, int);
		~Petak();

		int TotalMakhlukinPetak();
		Makhluk* spawn();
		Makhluk* spawn(int, int, int);
		void MoveMakhluk(int, int);
		void showWorld();
		void showPetak(int, int);


	private :
		ListMakhluk **Cell;
		int nTotalMakhluk;
		int panjang;
		int lebar;

};

#endif //PETAK_H


