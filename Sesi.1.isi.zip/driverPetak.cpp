#include "Petak.h"
#include "windows.h"
#include <math.h>
#include <iostream>

using namespace std;

int main()
{
	Petak P(10,20);
	double delT = 0.1;

	Makhluk *M[20];

	M[0] = P.spawn(5,5,2);

	while (P.TotalMakhlukinPetak() > 0)
	{
		system("CLS");
		P.showWorld();
		cout << endl;
//		cout << "here?" << endl;

		cout << M[0]->getdeltaT() << " " << delT << endl;
		cout << M[0]->getX() << " " << M[0]->getY() << endl;

		int nilaiX = M[0]->getX();
		int nilaiY = M[0]->getY();
//		P.showPetak(nilaiX,nilaiY);
		Sleep(4000);
		delT = delT+0.1;
		M[0]->move();
	}


return 0;
}
