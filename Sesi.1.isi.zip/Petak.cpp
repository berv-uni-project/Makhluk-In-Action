#include "Petak.h"
#include <iostream>

using namespace std;

/**
* Ctor untuk petak, menginisialisasi seluruh cell dengan ctor list of mahkluk
**/

#define Nil NULL

Petak::Petak()
{
	panjang = 10;
	lebar  = 10;

	Cell = new ListMakhluk *[panjang];
	for (int i = 0; i<panjang; i++)
		Cell[i] = new ListMakhluk[lebar];

	cout << "ctor petak" << endl;
}

Petak::Petak(int _panjang, int _lebar)
{
	lebar  = _lebar;
	panjang = _panjang;
	Cell = new ListMakhluk *[panjang];
	for (int i = 0; i<panjang; i++)
		Cell[i] = new ListMakhluk[lebar];

	cout << "ctor petak" << endl;
}

/**
* Dtor untuk petak, menghapus seluruh petak yang ada di dunia
**/
Petak::~Petak()
{
	for (int i=0; i<panjang; i++)
		delete [] Cell;
	delete [] Cell;
	cout << "dtor petak" << endl;
}


/**
* Secara random membuat makhluk spawn
**/

Makhluk* Petak::spawn()
{
	srand(time(NULL));	int baris = rand() % panjang;
	srand(time(NULL));	int kolom = rand() % lebar;
	srand(time(NULL));	int tipe = rand() % 5 + 1;
	Makhluk *M;

	switch (tipe)
	{
	case 1:
		M = new MakhlukAntiAir(baris, kolom);
		break;
	case 2:
		M = new MakhlukBurukRupa(baris, kolom);
		break;
	case 3:
		M = new MakhlukMaling(baris, kolom);
		break;
	case 4:
		M = new MakhlukMonster(baris, kolom);
		break;
	case 5:
		M = new MakhlukTerbang(baris, kolom);
		break;
	default:
		M = new MakhlukAntiAir(baris, kolom);
	}

	Cell[baris][kolom].AddMakhluk(M);
	nTotalMakhluk++;

	cout << "spawn" << endl;
	return M;
}

Makhluk* Petak::spawn(int i, int j, int t)
{
	int baris = i;
	int kolom = j;
	int tipe = t;

	Makhluk *M;

	switch (tipe)
	{
		case 1 :
			M = new MakhlukAntiAir(baris, kolom);
			break;
		case 2 :
			M = new MakhlukBurukRupa(baris, kolom);
			break;
		case 3 :
			M = new MakhlukMaling(baris, kolom);
			break;
		case 4 :
			M = new MakhlukMonster(baris, kolom);
			break;
		case 5 :
			M = new MakhlukTerbang(baris, kolom);
			break;
		default :
			M = new MakhlukAntiAir(baris, kolom);
	}

	Cell[baris][kolom].AddMakhluk(M);
	nTotalMakhluk++;

	cout << "spawn" << endl;
return M;
}


/**
* Update seluruh petak dan menampilkan makhluk yang ada
**/
void Petak::showWorld()
{
	for (int i = 0; i < panjang; i++)
	{
		for (int j = 0; j < lebar; j++)
		{
			MoveMakhluk(i, j);
		}
	}

	for (int i=0; i < panjang; i++)
	{
		for (int j=0; j < lebar; j++)
		{
			cout << "|";
			Cell[i][j].showlist();
			int n = Cell[i][j].GetnMakhluk();
			for (int i = n; i<4; i++)
				cout << " ";
		}
		cout << endl;
	}
	cout << "tampilan petak" << endl;
}

void Petak::MoveMakhluk(int i, int j)
{
	bool exit = false;
	if (Cell[i][j].isEmpty()==false)
	{
		Node *M;
		do
		{
			M = Cell[i][j].checkMoveMakhluk(i,j);
			if (M!=Nil)
			{
				int x = M->GetVal()->getX();
				int y = M->GetVal()->getY();
				if ((x <= panjang) && (y <= lebar) && (x >= 0) && (y >= 0))
				{
					Cell[x][y].AddMakhluk(M);
					if (Cell[x][y].isFull())
					{
						Cell[x][y].SurvFight();
						nTotalMakhluk--;
					}
				}
				else
				{
					delete &M;
					nTotalMakhluk--;
					Node *M = Cell[i][j].checkMoveMakhluk(i,j);
					exit = true;
				}
			}
		} while ((M != Nil)&&(exit==false));
	}
}

int Petak::TotalMakhlukinPetak()
{
	cout << "total mahkluk" << endl;
	return nTotalMakhluk;
}

void Petak::showPetak(int i, int j)
{
	cout << "isi dari Cell " << i << " " <<  j << endl;
	Cell[i][j].showlist();
	cout << endl;
}


