#ifndef PETAK_H
#define PETAK_H

#include "ListMakhluk.h"
#include "MakhlukAntiAir.h"
#include "MakhlukBurukRupa.h"
#include "MakhlukMaling.h"
#include "MakhlukMonster.h"
#include "MakhlukTerbang.h"
#include <iostream>
#include <cstdlib>
#include <time.h>


class Petak {
	public :
		Petak();
		Petak(int, int);
		~Petak();

		int TotalMakhlukinPetak();
		Makhluk* spawn();
		Makhluk* spawn(int, int, int);
		void MoveMakhluk(int, int);
		void showWorld();
		void showPetak(int, int);


	private :
		ListMakhluk **Cell;
		int nTotalMakhluk;
		int panjang;
		int lebar;

};

#endif //PETAK_H


