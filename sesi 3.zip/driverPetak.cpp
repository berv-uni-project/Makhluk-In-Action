#include "Petak.h"
#include "windows.h"
#include <math.h>
#include <iostream>

using namespace std;

int main()
{
	Petak P(10,20);
	double delT = 0.1;

	Makhluk *M[20];

	M[0] = P.spawn(5, 5, 1);
	M[1] = P.spawn(5, 4, 2);

	while (P.TotalMakhlukinPetak() > 0)
	{
		system("CLS");
		P.showWorld();
		cout << endl;
		Sleep(500);
		M[1]->move();
	}


return 0;
}