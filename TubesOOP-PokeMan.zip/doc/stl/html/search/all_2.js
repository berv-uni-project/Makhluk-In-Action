var searchData=
[
  ['deletemakhluk',['DeleteMakhluk',['../class_himp_makhluk.html#abd19a0032152cc4a3868c94a414b1570',1,'HimpMakhluk']]]
];
