var searchData=
[
  ['himpmakhluk',['HimpMakhluk',['../class_himp_makhluk.html',1,'HimpMakhluk'],['../class_himp_makhluk.html#a9f1c84ba255fc5f1827b44774818cee6',1,'HimpMakhluk::HimpMakhluk()']]]
];
