var searchData=
[
  ['addmakhluk',['AddMakhluk',['../class_list_makhluk.html#aba27ef0c4555b0bd355c0de92a8978a1',1,'ListMakhluk::AddMakhluk(Makhluk *)'],['../class_list_makhluk.html#ac6897ed52775baa2bab14fd894580e0f',1,'ListMakhluk::AddMakhluk(Node *)']]]
];
