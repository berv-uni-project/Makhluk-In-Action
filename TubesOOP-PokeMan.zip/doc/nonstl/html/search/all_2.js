var searchData=
[
  ['deleteafter',['DeleteAfter',['../class_list_makhluk.html#acc6802b2c58f836e1ac772c151ea255a',1,'ListMakhluk']]],
  ['deletefirst',['DeleteFirst',['../class_list_makhluk.html#abdc775f4e223b224587bf447b94968da',1,'ListMakhluk']]],
  ['deletelast',['DeleteLast',['../class_list_makhluk.html#a0504e6565a5195a86f34c0799b726391',1,'ListMakhluk']]]
];
