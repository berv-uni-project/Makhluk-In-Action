#ifndef View_H
#define View_H

#include <iostream>
//PIC Unit Test : Joshua Salimin 13514001
//Dibuat oleh : Joshua Salimin 13514001

class View {
	public :
		//hanya berisi Ctor dan Dtor karena hanya berisi layout
		View();
		~View();
		void ShowBentuk(int a);
		char GetBentuk(int a);
		
	private :

};



#endif //PETAK_H
