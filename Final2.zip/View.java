
import javax.swing.JFrame;

/**
 * @author Bervianto Leo P - 13514047
 * */

public class View extends JFrame {
    /**type of makhluk 1.*/
    private static final int MAKHLUK1 = 1;
    /**type of makhluk 2.*/
    private static final int MAKHLUK2 = 2;
    /**type of makhluk 3.*/
    private static final int MAKHLUK3 = 3;
    /**type of makhluk 4.*/
    private static final int MAKHLUK4 = 4;
    /**type of makhluk 5.*/
    private static final int MAKHLUK5 = 5;
    /**type of player.*/
    private static final int PLAYER = 0;
    /**evolution level of player (1).*/
    private static final int P_STATE_1 = 1;
    /**evolution level of player (2).*/
    private static final int P_STATE_2 = 2;
    /**evolution level of player (3).*/
    private static final int P_STATE_3 = 3;
    /**evolution level of player (4).*/
    private static final int P_STATE_4 = 4;

    /**Prosedur menampilkan bentuk dengan suatu parameter.
    * @param a sebagai parameter untuk menampilkan sesuatu*/
    public final void showBentuk(final int a) {
        switch (a) {
            case MAKHLUK1:
                System.out.print('*');
                break;
            case MAKHLUK2:
                System.out.print('%');
                break;
            case MAKHLUK3:
                System.out.print('$');
                break;
            case MAKHLUK4:
                System.out.print('@');
                break;
            case MAKHLUK5:
                System.out.print('~');
                break;
            case PLAYER:
                switch (MakhlukPlayer.getEvolution()) {
                    case P_STATE_1:
                        System.out.print('A');
                        break;
                    case P_STATE_2:
                        System.out.print('B');
                        break;
                    case P_STATE_3:
                        System.out.print('C');
                        break;
                    case P_STATE_4:
                        System.out.print('D');
                        break;
                    default:
                        System.out.print('E');
                }
                break;
            default:
                System.out.print(' ');
                break;
        }
    }

    /**
    * fungsi mendapatkan bentuk dan mengembalikan bentuk.
    * @param a sebagai indikator untuk memberikan bentuk
    * @return bentuk hasil convert tipe
    * */
    public final char getBentuk(final int a) {
        char c;
        switch (a) {
            case MAKHLUK1:
                c = '*';
                break;
            case MAKHLUK2:
                c = '%';
                break;
            case MAKHLUK3:
                c = '$';
                break;
            case MAKHLUK4:
                c = '@';
                break;
            case MAKHLUK5:
                c = '~';
                break;
            case PLAYER:
                switch (MakhlukPlayer.getEvolution()) {
                    case P_STATE_1:
                        c = 'A';
                        break;
                    case P_STATE_2:
                        c = 'B';
                        break;
                    case P_STATE_3:
                        c = 'C';
                        break;
                    case P_STATE_4:
                        c = 'D';
                        break;
                    default:
                        c = 'E';
                }
                break;
            default:
                c = ' ';
                break;
        }
    return c;
    }
}
