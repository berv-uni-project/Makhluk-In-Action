/**
 * @author JJ
 */

public final class MakhlukPlayer extends Makhluk {

    /**const direction for case 1.*/
    private static final int DIR1 = 1;
    /**const direction for case 2.*/
    private static final int DIR2 = 2;
    /**const direction for case 3.*/
    private static final int DIR3 = 3;
    /**const direction for case 4.*/
    private static final int DIR4 = 4;
    /** known static x location of player.*/
    private static int xPlayer;
    /** known static y location of player.*/
    private static int yPlayer;
    /** default powerlevel.*/
    private static final int DEFAULT_POWERLEVEL = 60;
    /** powerlevel required for evolving.*/
    private static final int EVOLVE_REQ = 10;
    /** evolution level.*/
    private static int evolution;
    /** static player of this game. */
    private static MakhlukPlayer player;
     /** private constructor of MakhlukPlayer, setting all value.
     * @param a
     * @param b
     */
    private MakhlukPlayer(final int a, final int b) {
        powerlevel = DEFAULT_POWERLEVEL;
        type = 0;
        age = 0;
        agenow = -1;
        xPlayer = a;
        yPlayer = b;
        x = xPlayer;
        y = yPlayer;
        evolution = 1;
    }


    /**Creating player.
     * @param a
     * @param b */
    public static void spawnPlayer(final int a, final int b) {
        player = new MakhlukPlayer(a, b);
    }

    @Override
    public final void move() {
        x = xPlayer;
        y = yPlayer;
    }

    /** static method to make make player go up. */
    public static void playerUp() {
        xPlayer--;
    }
    /** static method to make make player go down. */
    public static void playerDown() {
        xPlayer++;
    }
    /** static method to make make player go right. */
    public static void playerRight() {
        yPlayer++;
    }
    /** static method to make make player go left. */
    public static void playerLeft() {
        yPlayer--;
    }

    /**.
     * procedure to notify that player has eaten something.
     * powerlevel will be increased by 1 every Makhluk Player eat
     * also trigger for evolving
     */
    public void playerEat() {
        powerlevel = powerlevel + 1;
        int realpower = evolution * EVOLVE_REQ;
        int powernow = powerlevel - DEFAULT_POWERLEVEL - realpower;
        if (powernow > 2) {
            evolution++;
        }
    }

    /**return makhluk player of this game.
     * @return player*/
    public static Makhluk getPlayer() {
        return player;
    }
   /**return makhluk player of this game.
     * @return player*/
    public static MakhlukPlayer getMPlayer() {
        return player;
    }

    /**return player evolution level.
     * @return evolution*/
    public static int getEvolution() {
        return evolution;
    }
}
